package com.example.presiden;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
;

public class MainActivity extends AppCompatActivity {
    ListView listView;

    String[] fruitNames = {"Soekarno","Soeharto","Habibie","Abdurrahman Wahid","Megawati","Susilo bambang yudhoyono","Jokowi"};
    int[] fruitImages = {R.drawable.soekarno,R.drawable.soeharto,R.drawable.habibie,R.drawable.gusdur,R.drawable.megawati,R.drawable.sby,R.drawable.jokowi};
    String[] deskripsi = {
            "Lahir\tKoesno Sosrodihardjo\n" +
                    "6 Juni 1901\n" +
                    "Bendera Belanda Surabaya, Jawa Timur, Hindia Belanda\n" +
                    "Meninggal dunia\t21 Juni 1970 (umur 69)\n" +
                    "Bendera Indonesia Jakarta\n" +
                    "Kebangsaan\tBendera Indonesia Indonesiar",
            "rezim",
            "the mr craks",
            "bapak perdamaian",
            "banteng betina",
            "banyak utang",
            "cebong"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview);

        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(getApplicationContext(), ListdataActivity.class);
                intent.putExtra("name", fruitNames[i]);
                intent.putExtra("image", fruitImages[i]);

                intent.putExtra("deskripsi", deskripsi[i]);
                startActivity(intent);

            }
        });

    }

    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return fruitImages.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }
            @Override
            public View getView ( int i, View view, ViewGroup viewGroup){
                View view1 = getLayoutInflater().inflate(R.layout.row_data, null);
                //getting view in row_data
                TextView name = view1.findViewById(R.id.fruits);
                ImageView image = view1.findViewById(R.id.images);

                name.setText(fruitNames[i]);
                image.setImageResource(fruitImages[i]);
                return view1;

        }
    }
}